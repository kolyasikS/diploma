import React from 'react';
import LoginCard from "@/app/(auth)/login/components/login-card";

const Page = () => {
  return (
      <LoginCard/>
  );
};

export default Page;