export const dynamic = 'force-dynamic';

import React from 'react';
import Dashboard from "@/app/(member)/worker/dashboard/components/Dashboard";

const Page = async () => {
  return (
    <div>
        <Dashboard/>
    </div>
  );
};

export default Page;