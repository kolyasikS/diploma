export const GET_ALL_WORKER_TASKS_QK = 'all_worker_tasks_qk'
