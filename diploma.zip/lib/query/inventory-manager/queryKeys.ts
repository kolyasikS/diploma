export const GET_LACKING_ITEMS_QK = 'lacking_items_qk'
export const GET_ITEMS_HISTORIES_QK = 'items_histories_qk'
export const GET_MOST_POPULAR_ITEM_QK = 'most_popular_item_qk'
