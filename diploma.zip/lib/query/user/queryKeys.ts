export const GET_ALL_USERS_QK = 'all_users_qk'
export const GET_ALL_ITEMS_QK = 'all_items_qk'
export const GET_ALL_ROLES_QK = 'all_roles_qk'
export const GET_ASSIGNMENT_STATUSES_QK = 'assignment_statuses_qk'
