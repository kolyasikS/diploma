export const GET_ALL_USER_TASKS_QK = 'all_user_tasks_qk'
export const GET_ASSIGNMENTS_QK = 'assignments_qk'
